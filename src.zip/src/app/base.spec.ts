import { Base } from './base';

describe('Base', () => {
  it('should create an instance', () => {
    expect(new Base()).toBeTruthy();
  });
});
